<?php 
	require '../function.php';

	$artikel = query("SELECT * FROM artikel");
?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<script type="text/javascript" src="flow.js"></script>
	<script type="text/javascript" href="flow.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro">
</head>
<body>
<div class="main">
	<div class="container">
	<!-- Navigation Bar -->
	<nav>
		<div id="navbar">
			<ul id="navlink">
				<li class="list"><a href="../home.html" id="navlink-1">Home</a></li>
				<li class="list"><a href="destinasi.php" id="navlink-1">Destinasi</a></li>
				<li class="list"><a href="../postdata.php" id="navlink-1">Post</a></li>
				<li class="list"><a href="../myTeam.html" id="navlink-1">About</a></li>
				<li class="login" id="navlink-1"><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
	</nav>

	<!-- Konten pantai baron -->
	<section id="content-lokasi-destinasi">
		<div id="bagian-kiri-destinasi">
			<a href="pantaiBaron.html"><img src="pantai-baron/1.jpg"></a>
		</div>

		<div id="bagian-kanan-destinasi">
			<div id="deskripsi">
				<p>Pantai Baron adalah salah satu objek wisata berupa pantai yang terletak di Desa Kemadang, Kecamatan Tanjungsari, Kabupaten Gunungkidul. Lokasi Pantai Baron dapat ditempuh 40 km daeri pusat kota Yogyakarta. Asal mula nama Pantai Baron berasal dari nama seorang bangsawan asal Belanda yang bernama Baron Skeber.</p>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-ticket" aria-hidden="true"></i>	
				</div>
				<div class="keterangan">
					<br>
					<span>Rp10.000</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-clock-o" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span>Jam Buka : 24 Jam</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-map-pin" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span>Rejosari, Kemadang, Tanjungsari, Kabupaten Gunung kidul, Daerah Istimewa Yogyakarta</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<a href="#" class="fa fa-trash del-btn"></a>
				</div>
				<div class="keterangan">
					<a href="#" class="fa fa-plus upd-btn"></a>
				</div>
			</div>
		</div>
	</section>

	<!-- Konten candi boko -->
	<section id="content-lokasi-destinasi">	
		<div id="bagian-kiri-destinasi">
			<a href="candiBoko.html"><img src="candi-boko/3.jpg"></a>
		</div>

		<div id="bagian-kanan-destinasi">
			<div id="deskripsi">
				<p>Situs Ratu Boko atau Istana Raja Baka adalah situs purbakala yang merupakan kompleks sejumlah sisa bangunan yang berada kira-kira 3 km di sebelah selatan dari kompleks Candi Prambanan, 18 km sebelah timur Kota Yogyakarta atau 50 km barat daya Kota Surakarta, Jawa Tengah, Indonesia.</p>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-ticket" aria-hidden="true"></i>	
				</div>
				<div class="keterangan">
					<br>
					<span>Rp20.000-Rp75.000</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-clock-o" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span>Jam Buka : 08.00-17.00</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-map-pin" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span>Jl. Raya Piyungan - Prambanan No.KM.2, Gatak, Bokoharjo, Kec. Prambanan, Kabupaten Sleman, Daerah Istimewa Yogyakarta</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<a href="#" class="fa fa-trash del-btn"></a>
				</div>
				<div class="keterangan">
					<a href="#" class="fa fa-plus upd-btn"></a>
				</div>
			</div>
		</div>
	</section>

	<!-- Konten titik nol -->
	<section id="content-lokasi-destinasi">	
		<div id="bagian-kiri-destinasi">
			<a href="titikNol.html"><img src="titik-nol/1.jpg"></a>
		</div>

		<div id="bagian-kanan-destinasi">
			<div id="deskripsi">
				<p>Titik nol kilometer di Yogyakarta merupakan kawasan yang kerap dikunjungi wisatawan lantaran lokasinya dekat dengan beberapa tempat wisata. Tidak hanya itu, titik nol kilometer juga memiliki beberapa bangunan kuno dan suasana vintage yang membuat pengunjung senang berjalan-jalan di sana.</p>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-ticket" aria-hidden="true"></i>	
				</div>
				<div class="keterangan">
					<br>
					<span>Rp5.000(Hanya bayar parkir)</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-clock-o" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span>Jam Buka : 24 Jam</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-map-pin" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span>Jl. Pangurakan No.1, Ngupasan, Kec. Gondomanan, Kota Yogyakarta, Daerah Istimewa Yogyakarta 55122</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<a href="#" class="fa fa-trash del-btn"></a>
				</div>
				<div class="keterangan">
					<a href="#" class="fa fa-plus upd-btn"></a>
				</div>
			</div>
		</div>
	</section>

	<!-- Konten pantai parangtritis -->
	<section id="content-lokasi-destinasi">	
		<div id="bagian-kiri-destinasi">
			<a href="pantaiParangtritis.html"><img src="pantai-parangtritis/1.jpg"></a>
		</div>

		<div id="bagian-kanan-destinasi">
			<div id="deskripsi">
				<p>Tentu sudah tidak asing lagi bagi traveler, pantai yang sangat indah bahkan menjadi salah satu ikon di Kabupaten Bantul. Pantai Parangtritis berada di daerah selatan Yogyakarta sekitar 28 kilometer dari pusat kota Yogyakarta. Pantai yang berpasir hitam ini sangat cocok untuk liburan kalian bersama keluarga atau teman.</p>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-ticket" aria-hidden="true"></i>	
				</div>
				<div class="keterangan">
					<br>
					<span>Rp10.000</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-clock-o" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span>Jam Buka : 24 Jam</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-map-pin" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span>Kretek, Kecamatan Kretek, Bantul, Daerah Istimewa Yogyakarta</span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<a href="#" class="fa fa-trash del-btn"></a>
				</div>
				<div class="keterangan">
					<a href="#" class="fa fa-plus upd-btn"></a>
				</div>
			</div>
		</div>
	</section>

	<?php foreach ($artikel as $row) : ?>
		
		<section id="content-lokasi-destinasi">	
		<div id="bagian-kiri-destinasi">
			<a href="tampilkandata.php?id=<?= $row["id"]; ?>"><img src="../uploadImg/<?= $row["gambar"]; ?>"></a>
		</div>

		<div id="bagian-kanan-destinasi">
			<div id="deskripsi">
				<?php echo $row["deskripsi"]; ?>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-ticket" aria-hidden="true"></i>	
				</div>
				<div class="keterangan">
					<br>
					<span><?= $row["harga_min"]; ?></span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-clock-o" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span><?= $row["jam_min"]; ?> - <?= $row["jam_maks"]; ?></span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-map-pin" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span><?= $row["alamat"]; ?></span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<a class="fa fa-trash del-btn" href="hapus.php?id=<?= $row["id"]; ?>" onclick="return confirm('Yakin untuk menghapus data?');"></a>
				</div>
				<div class="keterangan">
					<a href="../updateArtikel.php?id=<?= $row["id"]; ?>" class="fa fa-plus upd-btn"></a>
				</div>
			</div>
		</div>
	</section>

	<?php endforeach; ?>

	


<!-- Footer -->
	<section id="closing">	
		<h1>Kontak Kami</h1>
			<div class="bottom">
				<div class="row-footer-kiri">
					<h1>Email</h1>
					<ul class="ul-footer">
						<li class="ul-footer-list">19523059@students.uii.ac.id</li>
						<li class="ul-footer-list">19523202@students.uii.ac.id</li>
						<li class="ul-footer-list">19523230@students.uii.ac.id</li>
					</ul>
				</div>

				<div class="row-footer-kanan">
					<h1>About Us</h1>
					<p>Ini adalah versi situs web kami untuk Tugas Besar PABW Universitas Islam Indonesia Tahun 2020</p>
					<div id="icon-container">
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-twitter"></a>
					</div>
				</div>
			</div>
			<footer>
				<p><i>Copyright 2020 PABW Universitas Islam Indonesia</i></p>
			</footer>
	</section>

</div>
</div>
</body>
</html>