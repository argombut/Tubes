<?php 

	require '../function.php';
	
	$id = $_GET["id"];

	if( hapus($id) > 0 ){
		echo "<script>
			alert('Artikel dihapus!');
			document.location.href = 'destinasi.php';
			</script>";
		} else {
			echo "<script>
			alert('Artikel gagal dihapus');
			document.location.href = 'destinasi.php';
			</script>";
		}
?>