
<?php 
	require '../function.php';

	$id = $_GET["id"];
	$result = mysqli_query($conn, "SELECT * FROM artikel WHERE id = $id");
	$artikel = mysqli_fetch_assoc($result);
?>


<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<script type="text/javascript" src="flow.js"></script>
	<script type="text/javascript" href="flow.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro">
</head>
<body>
<div class="main">
<div class="container">
	<!-- Navigation Bar -->
	<nav>
		<div id="navbar">
			<ul id="navlink">
				<li class="list"><a href="../home.html" id="navlink-1">Home</a></li>
				<li class="list"><a href="destinasi.php" id="navlink-1">Destinasi</a></li>
				<li class="list"><a href="../postdata.php" id="navlink-1">Post</a></li>
				<li class="list"><a href="../myTeam.html" id="navlink-1">About</a></li>
				<li class="login" id="navlink-1"><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
	</nav>

	<!-- Judul -->
	<div class="header-content">
		<h1><?= $artikel["judul"]; ?></h1>
	</div>

	<!-- Isi Konten Lokasi -->
	<section id="content-lokasi">
		<div id="bagian-kiri">
			<div id="deskripsi">
				<p><?= $artikel["deskripsi"]; ?></p>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-ticket" aria-hidden="true"></i>	
				</div>
				<div class="keterangan">
					<br>
					<span><?= $artikel["harga_min"]; ?> - <?= $artikel["harga_maks"]; ?></span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-clock-o" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span>Jam Buka : <?= $artikel["jam_min"]; ?> - <?= $artikel["jam_maks"]; ?></span>
				</div>
			</div>
			<div class="keterangan-lokasi">
				<div class="logo-keterangan">
					<i class="fa fa-map-pin" aria-hidden="true"></i>
				</div>
				<div class="keterangan">
					<br>
					<span><?= $artikel["alamat"]; ?></span>
				</div>
			</div>
		</div>

		<div class="carousel-lokasi">
			<i class="fa fa-arrow-right" aria-hidden="true" id="nextBtn"></i>
			<i class="fa fa-arrow-left" aria-hidden="true" id="prevBtn"></i>
			<div class="carousel-slide">
				<img src="../uploadImg/<?= $artikel["gambar"]; ?>" id="lastClone">
<!-- 				<img src="candi-boko/1.jpg">
				<img src="candi-boko/2.jpg">
				<img src="candi-boko/3.jpg">
				<img src="candi-boko/1.jpg" id="firstClone"> -->
			</div>
		</div>
	</section>

<!-- Footer -->
	<section id="closing">	
		<h1>Kontak Kami</h1>
			<div class="bottom">
				<div class="row-footer-kiri">
					<h1>Email</h1>
					<ul class="ul-footer">
						<li class="ul-footer-list">19523059@students.uii.ac.id</li>
						<li class="ul-footer-list">19523202@students.uii.ac.id</li>
						<li class="ul-footer-list">19523230@students.uii.ac.id</li>
					</ul>
				</div>

				<div class="row-footer-kanan">
					<h1>About Us</h1>
					<p>Ini adalah versi situs web kami untuk Tugas Besar PABW Universitas Islam Indonesia Tahun 2020</p>
					<div id="icon-container">
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-twitter"></a>
					</div>
				</div>
			</div>
			<footer>
				<p><i>Copyright 2020 PABW Universitas Islam Indonesia</i></p>
			</footer>
	</section>
</div>
</div>

<script src="app.js"></script>
</body>
</html>