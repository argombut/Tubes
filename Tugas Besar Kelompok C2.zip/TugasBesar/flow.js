function konfirmasi() {
  var nama = document.getElementById("name").value;
  var nomor = document.getElementById("nomor").value;
  var pass = document.getElementById("pass").value;
  var verif = document.getElementById("verif").value;

  if (nama==="") {
    alert("Nama harus diisi!");
  }
  else if (nomor==="") {
    alert("Nomor HP harus diisi!");
  }
  else  if (pass==="" && verif==="") {
    alert("Password harus diisi!");
  }
  else{
    var konfir = window.confirm("Apakah anda yakin?");
    var text="";
    if (konfir===true) {
      text = "Selamat " + nama + " anda telah terdaftar";
    }
  }
  document.getElementById("hasil").innerHTML = text; 
}

