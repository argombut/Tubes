<?php 
	session_start();

	if (!isset($_SESSION["login"])) {
		header("Location: login.php");
		exit;
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<script type="text/javascript" src="flow.js"></script>
	<script type="text/javascript" href="flow.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro">
</head>
<body>
	<div class="container">
	<!-- Navigation Bar -->
		<nav>
		<div id="navbar">
			<ul id="navlink">
				<li class="list"><a href="home.html" id="navlink-1">Home</a></li>
				<li class="list"><a href="destinasi/destinasi.php" id="navlink-1">Destinasi</a></li>
				<li class="list"><a href="postdata.php" id="navlink-1">Post</a></li>
				<li class="list"><a href="myTeam.html" id="navlink-1">About</a></li>
				<li class="login" id="navlink-1"><a href="logout.php">Logout</a></li>
			</ul>
		</div>
		</nav>

	<!-- Background image -->
		<div class="home-top">
			<div class="overlay"></div>
			<div id="welcome">
				<h1>Perjalanan Anda Dimulai Disini</h1>
				<p>Kami memberikan opsi tempat terbaik untuk kunjungan anda selama di provinsi Daerah Istimewa Yogyakarta</p>
			</div>
		</div>

		<section id="isi-index">
			<!-- Pembuatan Garis -->
			<div class="header-content-index">
				<hr width="30%" id="garis-judul">
				<h1 id="intro-isi-index">Temukan di Jogja</h1>
				<hr width="30%" id="garis-judul">
			</div>

		<!-- Pembuatan isi konten index -->
			<!-- Konten index bagian kiri -->
			<div class="container-kiri-kanan">
				<div id="konten-index-kiri">
					<div id="judul-konten-index">
						<h1>Pemerintahan</h1>
					</div>
					<div id="isi-konten-index">
						<div id="deskripsi-index">
							<p>Yogyakarta menjadi satu-satunya daerah yang memiliki sistem pemerintahan dengan sistem kerajaan atau keraton. Sebelum masa kemerdekaan, ada dua daerah yang mewarisi sistem kerajaan, yakni Kesultanan Yogyakarta dan Kadipaten Paku Alaman. Kedudukan dua daerah ini sempat menjadi pembahasan yang panjang pasca kemerdekaan. Yakni menyangkut tentang apakah Jogja diberikan otonomi penuh seperti sebelumnya, atau disejajarkan dengan daerah lain dengan sistem demokrasi.</p>
						</div>	
					<div id="gambar-index">
						<img src="img/pemerintahan1.jpg">
					</div>
					</div>
				</div>

			<!-- Konten index bagian kanan -->
				<div id="konten-index-kanan">
					<div id="judul-konten-index">
						<h1>Kebudayaan</h1>
					</div>
					<div id="isi-konten-index">
						<div id="deskripsi-index">
							<p>DIY memiliki tidak kurang dari 515 Bangunan Cagar Budaya yang tersebar di 13 Kawasan Cagar Budaya. Keberadaan aset-aset budaya peninggalan peradaban tinggi masa lampau tersebut, dengan Kraton sebagai institusi warisan adiluhung yang masih terlestari keberadaannya, merupakan embrio, dan memberi spirit bagi tumbuhnya dinamika masyarakat dalam berkehidupan kebudayaan terutama dalam berseni budaya, dan beradat tradisi.</p>
						</div>	
					<div id="gambar-index">
						<img src="img/budaya1.jpg">
					</div>
					</div>
				</div>
			</div>

		<!-- Pembuatan isi konten index -->
			<!-- Konten index bagian kiri -->
			<div class="container-kiri-kanan">
				<div id="konten-index-kiri">
					<div id="judul-konten-index">
						<h1>Alam</h1>
					</div>
					<div id="isi-konten-index">
						<div id="deskripsi-index">
							<p>Secara umum keadaan Geografis Daerah Istimewa Yogyakarta terdiri dari daerah dataran yang berada pada kaki gunung Merapi pada ketinggian 900 meter di atas permukaan permukaan air laut dan miring kearah Selatan sampai di daerah pantai Samudera Indonesia yang lazimnya disebut sebagai pantai Laut Selatan. Untuk selanjutnya daearah yang terdiri dari gunung atau pegunungan yaitu lereng Merapi di Utara, pegunungan Menoreh di Bagian Barat, dan pegunungan Selatan yakni Gunung Kidul, di bagian sebelah Tenggara yang disebut dengan pegunungan Seribu.</p>
						</div>	
					<div id="gambar-index">
						<img src="img/alam1.jpg">
					</div>
					</div>
				</div>

			<!-- Konten index bagian kanan -->
				<div id="konten-index-kanan">
					<div id="judul-konten-index">
						<h1>Kuliner</h1>
					</div>
					<div id="isi-konten-index">
						<div id="deskripsi-index">
							<p>Jogja juga terkenal dengan kepopuleran kuliner yang ada disana. Banyak tempat yang menyediakan makanan asli khas Jogja.
							Makanan yang terkenal di jogja salah satunya adalah gudeg, salah satu makanan yang menjamur di daerah Jogja. Jogja sendiri juga memiliki minuman unik
							yang bisa kita temukan saat berjalan di daerah Malioboro. Yaitu kopi jos.</p>
						</div>	
					<div id="gambar-index">
						<img src="img/kuliner1.jpg">
					</div>
					</div>
				</div>
			</div>

			<div class="getting-started-container">
				<div class="getting-started-judul">
					<h1>Temukan seputar informasi mengenai Jogja Sekarang</h1>
				</div>
				<a href="home.html"><button class="index-btn" type="button">GET STARTED!</button></a>
			</div>

		</section>

	
		<!-- Footer -->
		<section id="closing">	
			<h1>Kontak Kami</h1>
			<div class="bottom">
				<div class="row-footer-kiri">
					<h1>Email</h1>
					<ul class="ul-footer">
						<li class="ul-footer-list">19523059@students.uii.ac.id</li>
						<li class="ul-footer-list">19523202@students.uii.ac.id</li>
						<li class="ul-footer-list">19523230@students.uii.ac.id</li>
					</ul>
				</div>

				<div class="row-footer-kanan">
					<h1>About Us</h1>
					<p>Ini adalah versi situs web kami untuk Tugas Besar PABW Universitas Islam Indonesia Tahun 2020</p>
					<div id="icon-container">
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-twitter"></a>
					</div>
				</div>
			</div>
			<footer>
				<p><i>Copyright 2020 PABW Universitas Islam Indonesia</i></p>
			</footer>
	</section>
	</div>
	
</body>
</html>