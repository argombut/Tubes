<?php 
	session_start();
	require 'function.php';

	if (isset($_SESSION["login"])) {
		header("Location: index.php");
		exit;
	}


	if (isset($_POST["login"])) {
		$username = $_POST["username"];
		$password = $_POST["password"];
	

	$result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");

	if (mysqli_num_rows($result) === 1) {
		
		//cek password
		$row = mysqli_fetch_assoc($result); //ambil 1 baris kumpulan data dari $result
		if(password_verify($password, $row["password"])){
			//mulai session
			$_SESSION["login"] = true;
			header("Location: index.php");
			exit;
		}
	}

	$error = true;
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="loginStyle.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro">
</head>
<body>
	<div class="home-top">
		<!-- <div class="overlay"></div> -->
		<div class="container">
			<h1>Login</h1>
			<?php if(isset($error)) : ?>
				<p style="font-style: italic; color: red;">Username atau password salah</p>
			<?php endif; ?>

			<form action="" method="post">
				<div class="form-group">
					<label>Username</label>
					<input type="text" name="username" class="form-control">					
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="password" class="form-control">					
				</div>
				<button class="submit-button" type="submit" name="login">Submit</button>
			</form>
			<p>Jika anda belum punya akun silahkan melakukan <a href="registrasi.php">registrasi</a></p>
		</div>
	</div>
</body>
</html>