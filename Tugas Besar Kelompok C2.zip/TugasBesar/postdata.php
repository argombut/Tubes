<?php 
	require 'function.php';
	session_start();

	if (isset($_POST["upload"])) {

		if (tambah($_POST) > 0) {
			echo "<script>
				alert('Artikel baru ditambahkan');
				document.location.href = 'destinasi/destinasi.php';
				</script>";
		} else{
			echo mysqli_error($conn);
		}

	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Posting Data</title>
	<link rel="stylesheet" type="text/css" href="fill.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro">
</head>
<body>
	<div class="main">
		<div class="container">
			<h1>Post Artikel Baru</h1>

			<form action="" method="post" enctype="multipart/form-data">
				<div class="form-group">
					<label>Judul</label>
					<input type="text" name="judul" class="form-control">					
				</div>
				<div class="form-group">
					<label>Deskripsi</label>
					<textarea class="form-control" name="deskripsi"></textarea>					
				</div>
				<div class="form-group">
					<label>Gambar</label>
					<input type="file" name="gambar" class="form-control">
				</div>
				<div class="form-group">
					<label>Harga Tiket</label>
					<div class="data">
						<label>Rp</label>
						<input type="text" name="harga_min" class="data-keterangan">
						<label>  -  Rp</label>
						<input type="text" name="harga_maks" class="data-keterangan">
					</div>
				</div>
				<div class="form-group">
					<label>Jam Buka</label>
					<div class="data">
						<input type="text" name="jam_min" class="data-keterangan">
						<label>  -  </label>
						<input type="text" name="jam_maks" class="data-keterangan">
					</div>
				</div>
				<div class="form-group">
					<label>Alamat</label>
					<textarea class="form-control" rows="4" name="alamat"></textarea>
				</div>

				<button class="submit-button" type="submit" name="upload">Submit</button>
			</form>
			<p>Jika sudah selesai upload artikel maka silahkan kembali ke <a href="home.html">Halaman Utama</a></p>
		</div>
	</div>
</body>
</html>