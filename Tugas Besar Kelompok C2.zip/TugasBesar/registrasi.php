<?php 
include 'function.php';

	if( isset($_POST["register"]) ){
		
		if (registrasi($_POST) > 0) {
			echo "<script>
				alert('User baru ditambahkan')
				</script>";
			header("Location: index.php");
		} else{
			echo mysqli_error($conn);
		}
	}
	
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Registrasi</title>
	<link rel="stylesheet" type="text/css" href="regisStyle.css">
	<script src="flow.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro">
</head>
<body>
<div class="main">
	<div class="container">
		<legend>Form Registrasi</legend>
		<table>
			<form action="" method="post">
			<tr>
				<td>Username</td>
				<td> : </td>
				<td><input type="text" name="username" id="name"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td> : </td>
				<td><input type="password" name="password" id="pass"></td>
			</tr>
			<tr>
				<td>Konfirmasi Password</td>
				<td> : </td>
				<td><input type="password" name="password2" id="verif"></td>
			</tr>
			<tr>
				<td colspan="3">
					<!-- <button onclick="konfirmasi()">Registrasi</button> -->
					<input type="submit" name="register" value="Register">
				</td>
			</tr>
		</form>
		</table>

	<p>Jika sudah memiliki akun kembali ke <a href="login.php">halaman login</a></p>
	<p align="center" id="hasil"></p>
	</div>
</div>
</body>
</html>