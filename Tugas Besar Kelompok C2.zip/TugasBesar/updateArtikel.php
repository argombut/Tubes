<?php 
	require 'function.php';

	//ambil id di url
	$id = $_GET["id"];

	//query data
	$data = query("SELECT * FROM artikel WHERE id = $id")[0];

	//ambil data di url
	if( isset($_POST["submit"]) ){

		//cek data berhasil diubah apa nggak
		if( ubah($_POST) > 0 ){
			echo "<script>
			alert('Artikel diubah!');
			document.location.href = 'destinasi/destinasi.php';
			</script>";
		} else {
			echo "<script>
			alert('Artikel gagal diubah');
			document.location.href = 'destinasi/destinasi.php';
			</script>";
		}
	}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Ubah Data</title>
 	<link rel="stylesheet" type="text/css" href="loginStyle.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro">
 </head>
 <body>
 	<div class="main">
 		<div class="overlay"></div>
		<div class="container">
			<h1>Update Artikel</h1>

			<form action="" method="post" enctype="multipart/form-data">

				<input type="hidden" name="id" value="<?= $data["id"]; ?>">

				<div class="form-group">
					<label>Judul</label>
					<input type="text" name="judul" class="form-control" value="<?= $data["judul"]; ?>">					
				</div>
				<div class="form-group">
					<label>Deskripsi</label>
					<textarea class="form-control" name="deskripsi" value="<?= $data["deskripsi"]; ?>"><?= $data["deskripsi"]; ?></textarea>					
				</div>
				<div class="form-group">
					<label>Gambar</label>
					<input type="file" name="gambar" class="form-control" value="<?= $data["gambar"]; ?>">
				</div>
				<div class="form-group">
					<label>Harga Tiket</label>
					<div class="data">
						<label>Rp</label>
						<input type="text" name="harga_min" class="data-keterangan" value="<?= $data["harga_min"]; ?>">
						<label>  -  Rp</label>
						<input type="text" name="harga_maks" class="data-keterangan" value="<?= $data["harga_maks"]; ?>">
					</div>
				</div>
				<div class="form-group">
					<label>Jam Buka</label>
					<div class="data">
						<input type="text" name="jam_min" class="data-keterangan" value="<?= $data["jam_min"]; ?>">
						<label>  -  </label>
						<input type="text" name="jam_maks" class="data-keterangan" value="<?= $data["jam_maks"]; ?>">
					</div>
				</div>
				<div class="form-group">
					<label>Alamat</label>
					<textarea class="form-control" rows="4" name="alamat"> <?= $data["alamat"]; ?></textarea>
				</div>

				<button class="submit-button" type="submit" name="submit" value="submit">Submit</button>
			</form>
			<p>Jika sudah selesai update artikel maka silahkan kembali ke <a href="home.html">Halaman Utama</a></p>
		</div>
 </body>
 </html>